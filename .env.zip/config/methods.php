<?php

return [
    'options' => [
        'Match Parent' => 'Equals',
        'Divide' => 'Divide',
        'Multiply' => 'Multiply',
        'Subtract' => 'Subtract',
        'Add' => 'Add',
    ],
];