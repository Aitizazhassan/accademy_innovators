<?php

return [
    'types' => [
        'Brick',
        'Mortar',
        'Washdown',
        'Anchors',
        'Flashing',
        'Insulation',
        'Joints',
        'CMU',
        'Rebar',
        'Grout',
        'Reinforcing',
        'Accessories',
        'GF',
        'Splitface',
        'Groundface',
        'Glazed',
        'Veneer Cmu',
        'Vol Bf',
    ],
];