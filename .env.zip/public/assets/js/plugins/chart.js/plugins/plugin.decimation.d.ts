declare namespace _default {
    const id: string;
    namespace defaults {
        const algorithm: string;
        const enabled: boolean;
    }
    function beforeElementsUpdate(chart: any, args: any, options: any): void;
    function destroy(chart: any): void;
}
export default _default;
